using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;

namespace UABEAvalonia
{
    class Program
    {
        //https://stackoverflow.com/a/37146916
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool AttachConsole(int dwProcessId);

        // Initialization code. Don't use any Avalonia, third-party APIs or any
        // SynchronizationContext-reliant code before AppMain is called: things aren't initialized
        // yet and stuff might break.
        [STAThread]
        public static void Main(string[] args)
        {
            bool usesConsole = false;
            if (Environment.OSVersion.Platform == PlatformID.Win32NT)
            {
                usesConsole = AttachConsole(-1);

                if (usesConsole)
                {
                    (int Left, int Top) = Console.GetCursorPosition();
                    Console.SetCursorPosition(0, Top);
                    Console.Write(new string(' ', Left));
                    Console.SetCursorPosition(0, Top);
                }
            }
            else if (Environment.OSVersion.Platform == PlatformID.Unix)
            {
                //outputs fine to console already with dotnet in my testing
                usesConsole = true;
            }

            AppDomain currentDomain = AppDomain.CurrentDomain;
            InstallPluginDependencyResolver(currentDomain);
            currentDomain.UnhandledException += new UnhandledExceptionEventHandler(UABEAExceptionHandler);

            if (args.Length > 0)
            {
                CommandLineHandler.CLHMain(args);
            }
            else
            {
                if (usesConsole)
                    CommandLineHandler.PrintHelp();
                BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
            }
        }

        private static void InstallPluginDependencyResolver(AppDomain domain)
        {
            domain.AssemblyResolve += (_, args) =>
            {
                string? name;
                try { name = new AssemblyName(args.Name).Name; }
                catch { return null; }
                if (string.IsNullOrWhiteSpace(name)) return null;

                string fileName = name + ".dll";
                string baseDir = AppContext.BaseDirectory;
                string[] candidates =
                {
                    Path.Combine(baseDir, fileName),
                    Path.Combine(baseDir, "plugins", fileName)
                };

                foreach (string candidate in candidates)
                {
                    if (!File.Exists(candidate)) continue;
                    try { return Assembly.LoadFrom(candidate); }
                    catch { }
                }
                return null;
            };
        }

        public static void UABEAExceptionHandler(object sender, UnhandledExceptionEventArgs args)
        {
            if (args.ExceptionObject is Exception ex)
            {
                File.WriteAllText("chase-obb-editor-crash.log", ex.ToString());
                if (Environment.OSVersion.Platform == PlatformID.Win32NT)
                {
                    // can't trust the process to be stable enough
                    // to even show an avalonia messagebox, do hacky
                    // vbscript instead
                    string mshtaArgs = "vbscript:Execute(\"CreateObject(\"\"WScript.Shell\"\").Popup CreateObject(\"\"Scripting.FileSystemObject\"\").OpenTextFile(\"\"chase-obb-editor-crash.log\"\", 1).ReadAll,,\"\"chase.lol editor crash (please report this crash with chase-obb-editor-crash.log)\"\" :close\")";
                    Process.Start(new ProcessStartInfo("mshta", mshtaArgs));
                }
                else
                {
                    Console.WriteLine("chase.lol editor crash (please report this crash with chase-obb-editor-crash.log)");
                    Console.WriteLine(ex.ToString());
                }
            }
        }

        // Avalonia configuration, don't remove; also used by visual designer.
        public static AppBuilder BuildAvaloniaApp()
            => AppBuilder.Configure<App>()
                .UsePlatformDetect()
                .LogToTrace();
    }
}
