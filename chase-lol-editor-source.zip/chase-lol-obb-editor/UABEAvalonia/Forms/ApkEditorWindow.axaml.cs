using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UABEAvalonia
{
    public partial class ApkEditorWindow : Window
    {
        private string _sourcePath;
        private string _workingDirectory;
        private readonly List<ApkArchiveEntryItem> _allEntries = new List<ApkArchiveEntryItem>();
        private readonly ObservableCollection<ApkArchiveEntryItem> _visibleEntries = new ObservableCollection<ApkArchiveEntryItem>();
        private bool _hasChanges;
        private bool _allowClose;

        // Avalonia's runtime XAML loader requires a public parameterless constructor.
        // The application normally opens this window with an APK path via the overload below.
        public ApkEditorWindow() : this(string.Empty)
        {
        }

        public ApkEditorWindow(string apkPath)
        {
            InitializeComponent();
            _sourcePath = string.IsNullOrWhiteSpace(apkPath) ? string.Empty : Path.GetFullPath(apkPath);
            _workingDirectory = CreateWorkingDirectory();

            gridApkEntries.ItemsSource = _visibleEntries;
            menuOpenApk.Click += MenuOpenApk_Click;
            menuSaveApk.Click += MenuSaveApk_Click;
            menuCloseApk.Click += MenuCloseApk_Click;
            menuReplaceApkEntry.Click += ReplaceSelected_Click;
            menuAddApkEntries.Click += AddFiles_Click;
            menuAddApkFolder.Click += AddFolder_Click;
            menuEditApkText.Click += EditText_Click;
            menuRenameApkEntry.Click += RenameSelected_Click;
            menuRemoveApkEntry.Click += RemoveSelected_Click;
            menuDecodeApk.Click += DecodeApk_Click;
            menuBuildApk.Click += BuildApk_Click;
            menuApkSigningHelp.Click += SigningHelp_Click;

            btnReplaceApk.Click += ReplaceSelected_Click;
            btnAddApkFiles.Click += AddFiles_Click;
            btnAddApkFolder.Click += AddFolder_Click;
            btnRenameApk.Click += RenameSelected_Click;
            btnRemoveApk.Click += RemoveSelected_Click;
            btnExportApk.Click += MenuSaveApk_Click;
            btnEditApkText.Click += EditText_Click;
            btnExtractApkEntry.Click += ExtractSelected_Click;
            btnExtractAllApkEntries.Click += ExtractAll_Click;
            btnDecodeApk.Click += DecodeApk_Click;
            btnBuildApk.Click += BuildApk_Click;
            btnApkSigningHelp.Click += SigningHelp_Click;
            boxApkSearch.TextChanged += BoxApkSearch_TextChanged;
            gridApkEntries.SelectionChanged += GridApkEntries_SelectionChanged;
            gridApkEntries.DoubleTapped += GridApkEntries_DoubleTapped;
            KeyDown += ApkEditorWindow_KeyDown;
            Closing += ApkEditorWindow_Closing;

            if (!string.IsNullOrWhiteSpace(_sourcePath))
            {
                LoadApk(_sourcePath);
            }
        }

        private static string CreateWorkingDirectory()
        {
            string path = Path.Combine(Path.GetTempPath(), "chase-lol-apk-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(path);
            return path;
        }

        private void LoadApk(string path)
        {
            using (FileStream fs = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Read, leaveOpen: false))
            {
                _allEntries.Clear();
                for (int i = 0; i < zip.Entries.Count; i++)
                {
                    ZipArchiveEntry entry = zip.Entries[i];
                    bool isDirectory = entry.FullName.EndsWith("/", StringComparison.Ordinal) || entry.FullName.EndsWith("\\", StringComparison.Ordinal);
                    _allEntries.Add(new ApkArchiveEntryItem(
                        i,
                        entry.FullName.Replace('\\', '/'),
                        entry.Length,
                        entry.CompressedLength,
                        GuessKind(entry.FullName, isDirectory),
                        isDirectory,
                        isAdded: false));
                }
            }

            _sourcePath = Path.GetFullPath(path);
            _hasChanges = false;
            lblApkFile.Text = Path.GetFileName(_sourcePath);
            Title = "APK Archive Editor - " + Path.GetFileName(_sourcePath) + " - chase.lol";
            lblApkStatus.Text = "Opened " + _sourcePath + " · Original file is not modified in-place.";
            ApplyFilter();
            UpdateSelectionDetails();
        }

        private static string GuessKind(string name, bool isDirectory)
        {
            if (isDirectory) return "Folder";
            if (IsOldApkSignature(name)) return "Old APK signature";
            string ext = Path.GetExtension(name).ToLowerInvariant();
            switch (ext)
            {
                case ".dex": return "Dalvik bytecode";
                case ".xml": return name.Equals("AndroidManifest.xml", StringComparison.OrdinalIgnoreCase) ? "Android XML" : "XML";
                case ".arsc": return "Resources table";
                case ".so": return "Native library";
                case ".png": case ".jpg": case ".jpeg": case ".webp": case ".gif": case ".bmp": return "Image";
                case ".ogg": case ".wav": case ".mp3": case ".m4a": case ".opus": return "Audio";
                case ".txt": case ".json": case ".properties": case ".smali": case ".html": case ".js": case ".css": case ".yml": case ".yaml": return "Text";
                case ".ttf": case ".otf": return "Font";
                case ".jar": case ".zip": return "Archive";
                default: return "File";
            }
        }

        private void ApplyFilter()
        {
            string query = boxApkSearch.Text?.Trim() ?? string.Empty;
            _visibleEntries.Clear();
            foreach (ApkArchiveEntryItem entry in _allEntries)
            {
                if (entry.IsDeleted) continue;
                if (query.Length > 0 && entry.Name.IndexOf(query, StringComparison.OrdinalIgnoreCase) < 0 &&
                    entry.Kind.IndexOf(query, StringComparison.OrdinalIgnoreCase) < 0)
                    continue;
                _visibleEntries.Add(entry);
            }
            lblApkEntryCount.Text = $"{_visibleEntries.Count:N0} shown · {_allEntries.Count(e => !e.IsDeleted):N0} active · {_allEntries.Count(e => e.IsDeleted):N0} removed";
        }

        private ApkArchiveEntryItem? SelectedEntry => gridApkEntries.SelectedItem as ApkArchiveEntryItem;

        private void GridApkEntries_SelectionChanged(object? sender, SelectionChangedEventArgs e) => UpdateSelectionDetails();

        private void GridApkEntries_DoubleTapped(object? sender, TappedEventArgs e)
        {
            if (SelectedEntry != null && !SelectedEntry.IsDirectory)
                _ = EditTextEntryAsync();
        }

        private void BoxApkSearch_TextChanged(object? sender, TextChangedEventArgs e) => ApplyFilter();

        private void ApkEditorWindow_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.Key == Key.F && e.KeyModifiers.HasFlag(KeyModifiers.Control))
            {
                boxApkSearch.Focus();
                e.Handled = true;
            }
            else if (e.Key == Key.S && e.KeyModifiers.HasFlag(KeyModifiers.Control))
            {
                _ = ExportRebuiltApkAsync();
                e.Handled = true;
            }
            else if (e.Key == Key.Delete)
            {
                _ = RemoveSelectedAsync();
                e.Handled = true;
            }
        }

        private void UpdateSelectionDetails()
        {
            ApkArchiveEntryItem? entry = SelectedEntry;
            lblApkSelected.Text = entry == null ? "Select an APK entry on the left." : $"{entry.Name}\n{entry.Size:N0} bytes";
            lblApkSelectedPath.Text = entry?.Name ?? "—";
            lblApkSelectedKind.Text = entry?.Kind ?? "—";
            lblApkSelectedStatus.Text = entry?.Status ?? "—";
            btnEditApkText.IsEnabled = entry != null && !entry.IsDirectory;
            btnExtractApkEntry.IsEnabled = entry != null && !entry.IsDirectory;
        }

        private async void MenuOpenApk_Click(object? sender, RoutedEventArgs e)
        {
            var selectedFiles = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Open APK archive",
                AllowMultiple = false,
                FileTypeFilter = new List<FilePickerFileType>
                {
                    new FilePickerFileType("Android package") { Patterns = new List<string> { "*.apk" } },
                    new FilePickerFileType("All files") { Patterns = new List<string> { "*" } }
                }
            });
            string[] paths = FileDialogUtils.GetOpenFileDialogFiles(selectedFiles);
            if (paths.Length == 0) return;
            await OpenAnotherApkAsync(paths[0]);
        }

        private async Task OpenAnotherApkAsync(string path)
        {
            if (_hasChanges)
            {
                string choice = await MessageBoxUtil.ShowDialogCustom(this, "Unexported changes", "Export your changes before opening another APK?", "Export", "Discard", "Cancel");
                if (choice == "Cancel" || choice == string.Empty) return;
                if (choice == "Export" && !await ExportRebuiltApkAsync()) return;
            }

            try
            {
                // Load first: if the selected file is not a valid ZIP/APK, keep the current staged session intact.
                LoadApk(path);
                ResetWorkingDirectory();
            }
            catch (Exception ex)
            {
                await ShowErrorAsync("Could not open APK", ex.Message);
            }
        }

        private async void ReplaceSelected_Click(object? sender, RoutedEventArgs e) => await ReplaceSelectedAsync();
        private async void AddFiles_Click(object? sender, RoutedEventArgs e) => await AddFilesAsync();
        private async void AddFolder_Click(object? sender, RoutedEventArgs e) => await AddFolderAsync();
        private async void RenameSelected_Click(object? sender, RoutedEventArgs e) => await RenameSelectedAsync();
        private async void RemoveSelected_Click(object? sender, RoutedEventArgs e) => await RemoveSelectedAsync();
        private async void EditText_Click(object? sender, RoutedEventArgs e) => await EditTextEntryAsync();
        private async void ExtractSelected_Click(object? sender, RoutedEventArgs e) => await ExtractSelectedAsync();
        private async void ExtractAll_Click(object? sender, RoutedEventArgs e) => await ExtractAllAsync();
        private async void MenuSaveApk_Click(object? sender, RoutedEventArgs e) => await ExportRebuiltApkAsync();
        private void MenuCloseApk_Click(object? sender, RoutedEventArgs e) => Close();

        private async Task ReplaceSelectedAsync()
        {
            ApkArchiveEntryItem? entry = SelectedEntry;
            if (entry == null || entry.IsDirectory) return;
            var selected = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Choose replacement file",
                AllowMultiple = false
            });
            string[] paths = FileDialogUtils.GetOpenFileDialogFiles(selected);
            if (paths.Length == 0) return;

            try
            {
                StageReplacement(entry, paths[0]);
                MarkChanged($"Staged replacement for {entry.Name}");
            }
            catch (Exception ex) { await ShowErrorAsync("Replacement failed", ex.Message); }
        }

        private async Task AddFilesAsync()
        {
            var selected = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Choose file(s) to add to the APK",
                AllowMultiple = true
            });
            string[] paths = FileDialogUtils.GetOpenFileDialogFiles(selected);
            foreach (string sourcePath in paths)
            {
                string defaultName = Path.GetFileName(sourcePath);
                string? archiveName = await PromptTextAsync("Add APK entry", "Enter the path inside the APK (use / for folders):", defaultName);
                if (archiveName == null) continue;
                try
                {
                    archiveName = NormalizeArchivePath(archiveName);
                    ApkArchiveEntryItem? existing = _allEntries.FirstOrDefault(e => !e.IsDeleted && string.Equals(e.Name, archiveName, StringComparison.Ordinal));
                    if (existing != null)
                    {
                        StageReplacement(existing, sourcePath);
                        MarkChanged($"Replaced existing entry: {archiveName}");
                    }
                    else
                    {
                        string stagedPath = StageFile(sourcePath);
                        var added = new ApkArchiveEntryItem(-1, archiveName, new FileInfo(stagedPath).Length, -1,
                            GuessKind(archiveName, false), false, isAdded: true)
                        {
                            ReplacementPath = stagedPath
                        };
                        _allEntries.Add(added);
                        MarkChanged($"Added entry: {archiveName}");
                    }
                }
                catch (Exception ex) { await ShowErrorAsync("Could not add file", ex.Message); }
            }
            ApplyFilter();
            SelectEntryByName(paths.Length == 1 ? Path.GetFileName(paths[0]) : null);
        }

        private async Task AddFolderAsync()
        {
            var selected = await StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
            {
                Title = "Choose folder to add recursively",
                AllowMultiple = false
            });
            string[] paths = FileDialogUtils.GetOpenFolderDialogFiles(selected);
            if (paths.Length == 0) return;
            string folder = paths[0];
            int count = 0;
            try
            {
                foreach (string sourcePath in Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories))
                {
                    string relative = Path.GetRelativePath(folder, sourcePath).Replace('\\', '/');
                    string archiveName = NormalizeArchivePath(relative);
                    ApkArchiveEntryItem? existing = _allEntries.FirstOrDefault(e => !e.IsDeleted && string.Equals(e.Name, archiveName, StringComparison.Ordinal));
                    if (existing != null)
                        StageReplacement(existing, sourcePath);
                    else
                    {
                        string stagedPath = StageFile(sourcePath);
                        var info = new FileInfo(stagedPath);
                        _allEntries.Add(new ApkArchiveEntryItem(-1, archiveName, info.Length, -1, GuessKind(archiveName, false), false, isAdded: true)
                        {
                            ReplacementPath = stagedPath
                        });
                    }
                    count++;
                }
                if (count > 0) MarkChanged($"Added or replaced {count} file(s) from {folder}");
                ApplyFilter();
            }
            catch (Exception ex)
            {
                if (count > 0) MarkChanged($"Partially added or replaced {count} file(s) from {folder}");
                await ShowErrorAsync("Could not add folder", ex.Message);
            }
        }

        private async Task RenameSelectedAsync()
        {
            ApkArchiveEntryItem? entry = SelectedEntry;
            if (entry == null) return;
            string? newName = await PromptTextAsync("Rename APK entry", "New path inside the APK:", entry.Name);
            if (newName == null) return;
            try
            {
                newName = NormalizeArchivePath(newName);
                ApkArchiveEntryItem? duplicate = _allEntries.FirstOrDefault(e => !e.IsDeleted && !ReferenceEquals(e, entry) && string.Equals(e.Name, newName, StringComparison.Ordinal));
                if (duplicate != null)
                {
                    await ShowErrorAsync("Name already exists", "Another active entry already uses that path. Choose a unique path.");
                    return;
                }
                entry.Name = newName;
                entry.RefreshStatus();
                MarkChanged("Renamed entry to " + newName);
                ApplyFilter();
                SelectEntryByName(newName);
            }
            catch (Exception ex) { await ShowErrorAsync("Invalid entry path", ex.Message); }
        }

        private async Task RemoveSelectedAsync()
        {
            ApkArchiveEntryItem? entry = SelectedEntry;
            if (entry == null) return;
            MessageBoxResult choice = await MessageBoxUtil.ShowDialog(this, "Remove APK entry?", $"Remove '{entry.Name}' from the rebuilt APK? The original APK will remain unchanged.", MessageBoxType.YesNo);
            if (choice != MessageBoxResult.Yes) return;
            entry.IsDeleted = true;
            MarkChanged("Marked for removal: " + entry.Name);
            ApplyFilter();
            UpdateSelectionDetails();
        }

        private async Task EditTextEntryAsync()
        {
            ApkArchiveEntryItem? entry = SelectedEntry;
            if (entry == null || entry.IsDirectory) return;
            try
            {
                if (entry.Size > 8 * 1024 * 1024)
                {
                    await ShowErrorAsync("Entry is too large", "Text editing is limited to 8 MB. Use Replace or Extract for larger entries.");
                    return;
                }
                byte[] bytes = ReadEntryBytes(entry);
                if (bytes.Length > 8 * 1024 * 1024)
                {
                    await ShowErrorAsync("Entry is too large", "Text editing is limited to 8 MB. Use Replace or Extract for larger entries.");
                    return;
                }
                if (!LooksLikeText(bytes))
                {
                    await ShowErrorAsync("Binary entry", "This entry is binary data. Use Replace to swap the file, or use APKTool to decode AndroidManifest.xml and compiled resources.");
                    return;
                }

                string original = new UTF8Encoding(false, false).GetString(bytes);
                string? edited = await ShowTextEditorAsync(entry.Name, original);
                if (edited == null || edited == original) return;
                string stagePath = Path.Combine(_workingDirectory, Guid.NewGuid().ToString("N") + ".txt");
                File.WriteAllText(stagePath, edited, new UTF8Encoding(false));
                entry.ReplacementPath = stagePath;
                entry.Size = new FileInfo(stagePath).Length;
                entry.CompressedSize = -1;
                entry.RefreshStatus();
                MarkChanged("Edited text entry: " + entry.Name);
                ApplyFilter();
                SelectEntryByName(entry.Name);
            }
            catch (Exception ex) { await ShowErrorAsync("Text edit failed", ex.Message); }
        }

        private async Task ExtractSelectedAsync()
        {
            ApkArchiveEntryItem? entry = SelectedEntry;
            if (entry == null || entry.IsDirectory) return;
            var selected = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "Extract APK entry",
                SuggestedFileName = Path.GetFileName(entry.Name)
            });
            string? target = FileDialogUtils.GetSaveFileDialogFile(selected);
            if (target == null) return;
            try { WriteEntryToFile(entry, target); lblApkStatus.Text = "Extracted " + entry.Name + " → " + target; }
            catch (Exception ex) { await ShowErrorAsync("Extraction failed", ex.Message); }
        }

        private async Task ExtractAllAsync()
        {
            var selected = await StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
            {
                Title = "Choose destination folder",
                AllowMultiple = false
            });
            string[] dirs = FileDialogUtils.GetOpenFolderDialogFiles(selected);
            if (dirs.Length == 0) return;
            string root = Path.GetFullPath(dirs[0]);
            try
            {
                int count = 0;
                foreach (ApkArchiveEntryItem entry in _allEntries.Where(e => !e.IsDeleted && !e.IsDirectory))
                {
                    string output = GetSafeExtractPath(root, entry.Name);
                    Directory.CreateDirectory(Path.GetDirectoryName(output)!);
                    WriteEntryToFile(entry, output);
                    count++;
                }
                lblApkStatus.Text = $"Extracted {count:N0} files to {root}";
            }
            catch (Exception ex) { await ShowErrorAsync("Extract all failed", ex.Message); }
        }

        private async Task<bool> ExportRebuiltApkAsync()
        {
            var selected = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "Export rebuilt APK (unsigned)",
                SuggestedFileName = Path.GetFileNameWithoutExtension(_sourcePath) + "_modified.apk",
                FileTypeChoices = new List<FilePickerFileType>
                {
                    new FilePickerFileType("Android package") { Patterns = new List<string> { "*.apk" } }
                }
            });
            string? outputPath = FileDialogUtils.GetSaveFileDialogFile(selected);
            if (outputPath == null) return false;
            if (!outputPath.EndsWith(".apk", StringComparison.OrdinalIgnoreCase)) outputPath += ".apk";
            outputPath = Path.GetFullPath(outputPath);
            if (string.Equals(outputPath, _sourcePath, StringComparison.OrdinalIgnoreCase))
            {
                await ShowErrorAsync("Choose a new filename", "The original APK cannot be overwritten from this editor. Choose a separate output file.");
                return false;
            }

            string outDir = Path.GetDirectoryName(outputPath)!;
            string tempPath = Path.Combine(outDir, "." + Path.GetFileName(outputPath) + ".chase-tmp-" + Guid.NewGuid().ToString("N"));
            try
            {
                lblApkStatus.Text = "Rebuilding APK archive...";
                await Task.Run(() => WriteRebuiltArchive(tempPath));
                File.Move(tempPath, outputPath, true);
                LoadApk(outputPath);
                ResetWorkingDirectory();
                lblApkStatus.Text = "Exported rebuilt APK: " + outputPath + " · It is unsigned and must be signed before installation.";
                await MessageBoxUtil.ShowDialog(this, "APK exported", "The rebuilt APK was exported. The old APK signature was removed because the package changed. Sign this output with Android SDK Build Tools apksigner before installing it.");
                return true;
            }
            catch (Exception ex)
            {
                try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { }
                await ShowErrorAsync("APK export failed", ex.Message);
                return false;
            }
        }

        private void WriteRebuiltArchive(string outputPath)
        {
            var originalsByIndex = _allEntries.Where(e => !e.IsAdded).ToDictionary(e => e.OriginalIndex);
            using FileStream sourceStream = File.Open(_sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            using ZipArchive source = new ZipArchive(sourceStream, ZipArchiveMode.Read, leaveOpen: false);
            using FileStream outputStream = File.Create(outputPath);
            using ZipArchive output = new ZipArchive(outputStream, ZipArchiveMode.Create, leaveOpen: false);

            for (int i = 0; i < source.Entries.Count; i++)
            {
                ZipArchiveEntry oldEntry = source.Entries[i];
                if (IsOldApkSignature(oldEntry.FullName)) continue;
                if (!originalsByIndex.TryGetValue(i, out ApkArchiveEntryItem? row) || row.IsDeleted) continue;
                string archiveName = NormalizeArchivePath(row.Name, allowDirectory: row.IsDirectory);
                if (row.IsDirectory && !archiveName.EndsWith("/", StringComparison.Ordinal)) archiveName += "/";
                string sourceReplacement = row.ReplacementPath ?? string.Empty;
                ZipArchiveEntry newEntry = output.CreateEntry(archiveName, CompressionLevel.Optimal);
                try { newEntry.LastWriteTime = ClampZipTime(oldEntry.LastWriteTime); } catch { }
                using Stream target = newEntry.Open();
                if (!string.IsNullOrEmpty(sourceReplacement))
                {
                    using FileStream replacement = File.OpenRead(sourceReplacement);
                    replacement.CopyTo(target);
                }
                else
                {
                    using Stream original = oldEntry.Open();
                    original.CopyTo(target);
                }
            }

            foreach (ApkArchiveEntryItem added in _allEntries.Where(e => e.IsAdded && !e.IsDeleted))
            {
                if (string.IsNullOrWhiteSpace(added.ReplacementPath) || !File.Exists(added.ReplacementPath))
                    throw new IOException("Missing staged data for APK entry: " + added.Name);
                string archiveName = NormalizeArchivePath(added.Name, allowDirectory: added.IsDirectory);
                ZipArchiveEntry newEntry = output.CreateEntry(archiveName, CompressionLevel.Optimal);
                try { newEntry.LastWriteTime = DateTimeOffset.Now; } catch { }
                using Stream target = newEntry.Open();
                using FileStream replacement = File.OpenRead(added.ReplacementPath);
                replacement.CopyTo(target);
            }
        }

        private static bool IsOldApkSignature(string name)
        {
            string normalized = name.Replace('\\', '/');
            if (!normalized.StartsWith("META-INF/", StringComparison.OrdinalIgnoreCase)) return false;
            string file = Path.GetFileName(normalized).ToUpperInvariant();
            return file == "MANIFEST.MF" || file.StartsWith("SIG-", StringComparison.Ordinal) ||
                   file.EndsWith(".SF", StringComparison.Ordinal) || file.EndsWith(".RSA", StringComparison.Ordinal) ||
                   file.EndsWith(".DSA", StringComparison.Ordinal) || file.EndsWith(".EC", StringComparison.Ordinal);
        }

        private static DateTimeOffset ClampZipTime(DateTimeOffset time)
        {
            if (time.Year < 1980) return new DateTimeOffset(1980, 1, 1, 0, 0, 0, TimeSpan.Zero);
            if (time.Year > 2107) return new DateTimeOffset(2107, 12, 31, 23, 59, 58, TimeSpan.Zero);
            return time;
        }

        private void StageReplacement(ApkArchiveEntryItem entry, string sourcePath)
        {
            if (!File.Exists(sourcePath)) throw new FileNotFoundException("The replacement file was not found.", sourcePath);
            string staged = StageFile(sourcePath);
            entry.ReplacementPath = staged;
            entry.Size = new FileInfo(staged).Length;
            entry.CompressedSize = -1;
            entry.RefreshStatus();
            ApplyFilter();
            SelectEntryByName(entry.Name);
        }

        private string StageFile(string sourcePath)
        {
            string target = Path.Combine(_workingDirectory, Guid.NewGuid().ToString("N") + Path.GetExtension(sourcePath));
            using FileStream input = File.Open(sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            using FileStream output = File.Create(target);
            input.CopyTo(output);
            return target;
        }

        private byte[] ReadEntryBytes(ApkArchiveEntryItem entry)
        {
            if (!string.IsNullOrEmpty(entry.ReplacementPath)) return File.ReadAllBytes(entry.ReplacementPath);
            if (entry.IsAdded) return Array.Empty<byte>();
            using FileStream fs = File.Open(_sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            using ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Read, leaveOpen: false);
            using Stream input = zip.Entries[entry.OriginalIndex].Open();
            using MemoryStream output = new MemoryStream();
            input.CopyTo(output);
            return output.ToArray();
        }

        private void WriteEntryToFile(ApkArchiveEntryItem entry, string targetPath)
        {
            if (!string.IsNullOrEmpty(entry.ReplacementPath))
            {
                using FileStream input = File.OpenRead(entry.ReplacementPath);
                using FileStream output = File.Create(targetPath);
                input.CopyTo(output);
                return;
            }
            if (entry.IsAdded) throw new IOException("The staged entry has no content: " + entry.Name);
            using FileStream fs = File.Open(_sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            using ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Read, leaveOpen: false);
            using Stream source = zip.Entries[entry.OriginalIndex].Open();
            using FileStream destination = File.Create(targetPath);
            source.CopyTo(destination);
        }

        private static bool LooksLikeText(byte[] bytes)
        {
            if (bytes.Length == 0) return true;
            int inspect = Math.Min(bytes.Length, 4096);
            int zero = 0;
            int control = 0;
            for (int i = 0; i < inspect; i++)
            {
                byte b = bytes[i];
                if (b == 0) zero++;
                if ((b < 0x09 || (b > 0x0D && b < 0x20)) && b != 0x1B) control++;
            }
            return zero == 0 && control < inspect / 20 + 2;
        }

        private async void DecodeApk_Click(object? sender, RoutedEventArgs e) => await DecodeWithApkToolAsync();
        private async void BuildApk_Click(object? sender, RoutedEventArgs e) => await BuildWithApkToolAsync();

        private async Task<string?> PickApkToolJarAsync()
        {
            var selected = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Select apktool.jar",
                AllowMultiple = false,
                FileTypeFilter = new List<FilePickerFileType>
                {
                    new FilePickerFileType("Java archive") { Patterns = new List<string> { "*.jar" } },
                    new FilePickerFileType("All files") { Patterns = new List<string> { "*" } }
                }
            });
            string[] paths = FileDialogUtils.GetOpenFileDialogFiles(selected);
            if (paths.Length == 0) return null;
            if (!Path.GetFileName(paths[0]).Contains("apktool", StringComparison.OrdinalIgnoreCase))
            {
                await ShowErrorAsync("Check the selected file", "Choose the official apktool.jar file, not another JAR.");
                return null;
            }
            return paths[0];
        }

        private async Task DecodeWithApkToolAsync()
        {
            string? jar = await PickApkToolJarAsync();
            if (jar == null) return;
            var selected = await StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
            {
                Title = "Choose parent folder for decoded APK project",
                AllowMultiple = false
            });
            string[] dirs = FileDialogUtils.GetOpenFolderDialogFiles(selected);
            if (dirs.Length == 0) return;
            string output = Path.Combine(dirs[0], Path.GetFileNameWithoutExtension(_sourcePath) + "_decoded");
            if (Directory.Exists(output))
            {
                await ShowErrorAsync("Output folder already exists", "Rename or move the existing folder, then run Decode again. Nothing was overwritten.");
                return;
            }
            await RunJavaToolAsync(jar, new[] { "d", _sourcePath, "-o", output }, "APKTool decode", output,
                "Decoded project created. Edit AndroidManifest.xml, res/, assets/, or smali files in the output folder. Build it again with APKTool when finished.");
        }

        private async Task BuildWithApkToolAsync()
        {
            string? jar = await PickApkToolJarAsync();
            if (jar == null) return;
            var selected = await StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
            {
                Title = "Select decoded APKTool project folder",
                AllowMultiple = false
            });
            string[] dirs = FileDialogUtils.GetOpenFolderDialogFiles(selected);
            if (dirs.Length == 0) return;
            if (!File.Exists(Path.Combine(dirs[0], "apktool.yml")))
            {
                await ShowErrorAsync("Not an APKTool project", "The selected folder does not contain apktool.yml. Decode an APK with APKTool first.");
                return;
            }
            var save = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "Save rebuilt APK (unsigned)",
                SuggestedFileName = Path.GetFileNameWithoutExtension(_sourcePath) + "_apktool.apk",
                FileTypeChoices = new List<FilePickerFileType> { new FilePickerFileType("Android package") { Patterns = new List<string> { "*.apk" } } }
            });
            string? output = FileDialogUtils.GetSaveFileDialogFile(save);
            if (output == null) return;
            if (!output.EndsWith(".apk", StringComparison.OrdinalIgnoreCase)) output += ".apk";
            if (string.Equals(Path.GetFullPath(output), _sourcePath, StringComparison.OrdinalIgnoreCase))
            {
                await ShowErrorAsync("Choose a new filename", "Do not overwrite the original APK.");
                return;
            }
            await RunJavaToolAsync(jar, new[] { "b", dirs[0], "-o", output }, "APKTool build", output,
                "APKTool created a rebuilt APK. APKTool outputs are unsigned; run zipalign (before signing when needed) and apksigner with a key you control before installing.");
        }

        private async Task RunJavaToolAsync(string jar, IEnumerable<string> args, string operation, string outputPath, string successMessage)
        {
            try
            {
                lblApkStatus.Text = operation + " running...";
                var result = await Task.Run(() =>
                {
                    ProcessStartInfo psi = new ProcessStartInfo
                    {
                        FileName = "java",
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        CreateNoWindow = true
                    };
                    psi.ArgumentList.Add("-jar");
                    psi.ArgumentList.Add(jar);
                    foreach (string arg in args) psi.ArgumentList.Add(arg);
                    using Process process = new Process { StartInfo = psi };
                    process.Start();
                    Task<string> stdout = process.StandardOutput.ReadToEndAsync();
                    Task<string> stderr = process.StandardError.ReadToEndAsync();
                    process.WaitForExit();
                    Task.WaitAll(stdout, stderr);
                    return (ExitCode: process.ExitCode, StdOut: stdout.Result, StdErr: stderr.Result);
                });

                string log = (result.StdOut + Environment.NewLine + result.StdErr).Trim();
                if (result.ExitCode != 0)
                {
                    await ShowErrorAsync(operation + " failed", "Exit code: " + result.ExitCode + Environment.NewLine + log +
                        (log.Contains("java", StringComparison.OrdinalIgnoreCase) ? string.Empty : Environment.NewLine + "Confirm Java is installed and available on PATH."));
                    lblApkStatus.Text = operation + " failed.";
                    return;
                }
                lblApkStatus.Text = operation + " completed: " + outputPath;
                await MessageBoxUtil.ShowDialog(this, operation + " complete", successMessage + Environment.NewLine + Environment.NewLine + log);
            }
            catch (Exception ex)
            {
                lblApkStatus.Text = operation + " failed.";
                await ShowErrorAsync(operation + " could not start", ex.Message + Environment.NewLine + "Install Java and make sure java.exe is available on PATH.");
            }
        }

        private async void SigningHelp_Click(object? sender, RoutedEventArgs e)
        {
            await MessageBoxUtil.ShowDialog(this, "APK signing", "Any edit or repack invalidates the original APK signature. To sign an output, install Android SDK Build Tools and use apksigner with a keystore you own. Example from a Developer/Command Prompt:\n\nzipalign -p -f 4 input-unsigned.apk aligned.apk\napksigner sign --ks my-release-key.jks --out signed.apk aligned.apk\napksigner verify --verbose signed.apk\n\nUse your own signing key. A different key generally cannot update the already-installed original app; package updates must be signed with the original developer's key. Do not share your keystore or password.");
        }

        private async Task<string?> ShowTextEditorAsync(string entryName, string originalText)
        {
            Window dialog = new Window
            {
                Title = "Edit text - " + entryName,
                Width = 780,
                Height = 580,
                MinWidth = 560,
                MinHeight = 360,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Background = new SolidColorBrush(Color.Parse("#EEF3F9"))
            };
            TextBox editor = new TextBox
            {
                Text = originalText,
                AcceptsReturn = true,
                AcceptsTab = true,
                TextWrapping = TextWrapping.NoWrap,
                FontFamily = new FontFamily("Consolas"),
                FontSize = 13,
                MinHeight = 220
            };
            ScrollViewer.SetHorizontalScrollBarVisibility(editor, Avalonia.Controls.Primitives.ScrollBarVisibility.Auto);
            ScrollViewer.SetVerticalScrollBarVisibility(editor, Avalonia.Controls.Primitives.ScrollBarVisibility.Auto);
            Button save = new Button { Content = "Apply changes", MinWidth = 110, Height = 32, Background = new SolidColorBrush(Color.Parse("#D3E7FA")), Foreground = new SolidColorBrush(Color.Parse("#183F65")) };
            Button cancel = new Button { Content = "Cancel", MinWidth = 90, Height = 32 };
            bool accepted = false;
            save.Click += (_, _) => { accepted = true; dialog.Close(); };
            cancel.Click += (_, _) => dialog.Close();
            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Spacing = 8 };
            buttons.Children.Add(cancel);
            buttons.Children.Add(save);
            Grid layout = new Grid { Margin = new Thickness(12), RowDefinitions = new RowDefinitions("*,Auto") };
            layout.Children.Add(editor);
            Grid.SetRow(buttons, 1);
            layout.Children.Add(buttons);
            dialog.Content = layout;
            await dialog.ShowDialog(this);
            return accepted ? editor.Text ?? string.Empty : null;
        }

        private async Task<string?> PromptTextAsync(string title, string prompt, string initialValue)
        {
            Window dialog = new Window
            {
                Title = title,
                Width = 560,
                Height = 190,
                MinWidth = 480,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Background = new SolidColorBrush(Color.Parse("#EEF3F9"))
            };
            TextBox input = new TextBox { Text = initialValue, Height = 32, VerticalContentAlignment = VerticalAlignment.Center };
            TextBlock label = new TextBlock { Text = prompt, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 8) };
            Button ok = new Button { Content = "OK", MinWidth = 86, Height = 31, Background = new SolidColorBrush(Color.Parse("#D3E7FA")), Foreground = new SolidColorBrush(Color.Parse("#183F65")) };
            Button cancel = new Button { Content = "Cancel", MinWidth = 86, Height = 31 };
            bool accepted = false;
            ok.Click += (_, _) => { accepted = true; dialog.Close(); };
            cancel.Click += (_, _) => dialog.Close();
            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Spacing = 8 };
            buttons.Children.Add(cancel);
            buttons.Children.Add(ok);
            Grid layout = new Grid { Margin = new Thickness(14), RowDefinitions = new RowDefinitions("Auto,Auto,*,Auto") };
            layout.Children.Add(label);
            Grid.SetRow(input, 1);
            layout.Children.Add(input);
            Grid.SetRow(buttons, 3);
            layout.Children.Add(buttons);
            dialog.Content = layout;
            input.KeyDown += (_, e) => { if (e.Key == Key.Enter && !e.KeyModifiers.HasFlag(KeyModifiers.Shift)) { accepted = true; dialog.Close(); } };
            await dialog.ShowDialog(this);
            return accepted ? input.Text?.Trim() : null;
        }

        private void MarkChanged(string status)
        {
            _hasChanges = true;
            lblApkStatus.Text = status + " · Export a rebuilt APK to apply changes.";
            UpdateSelectionDetails();
        }

        private static string NormalizeArchivePath(string name, bool allowDirectory = false)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Entry path cannot be empty.");
            string normalized = name.Trim().Replace('\\', '/');
            if (normalized.StartsWith("/", StringComparison.Ordinal) || Path.IsPathRooted(normalized) || normalized.Contains(':'))
                throw new ArgumentException("Use a relative path inside the APK, not an absolute filesystem path.");
            string[] parts = normalized.Split('/');
            if (parts.Any(p => p == ".." || p == ".")) throw new ArgumentException("Entry paths cannot contain . or .. path segments.");
            if (!allowDirectory) normalized = normalized.TrimEnd('/');
            if (normalized.Length == 0) throw new ArgumentException("Entry path cannot be empty.");
            return normalized;
        }

        private static string GetSafeExtractPath(string root, string archiveName)
        {
            string normalized = NormalizeArchivePath(archiveName, allowDirectory: true);
            string destination = Path.GetFullPath(Path.Combine(root, normalized.Replace('/', Path.DirectorySeparatorChar)));
            string rootPrefix = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (!destination.StartsWith(rootPrefix, StringComparison.OrdinalIgnoreCase))
                throw new IOException("The APK contains an unsafe path: " + archiveName);
            return destination;
        }

        private void SelectEntryByName(string? name)
        {
            if (string.IsNullOrEmpty(name)) return;
            ApkArchiveEntryItem? entry = _visibleEntries.FirstOrDefault(e => string.Equals(e.Name, name, StringComparison.Ordinal));
            if (entry == null) return;
            gridApkEntries.SelectedItem = entry;
            gridApkEntries.ScrollIntoView(entry, null);
            UpdateSelectionDetails();
        }

        private async Task ShowErrorAsync(string title, string message) => await MessageBoxUtil.ShowDialog(this, title, message);

        private void ResetWorkingDirectory()
        {
            try { if (Directory.Exists(_workingDirectory)) Directory.Delete(_workingDirectory, true); } catch { }
            _workingDirectory = CreateWorkingDirectory();
        }

        private async void ApkEditorWindow_Closing(object? sender, CancelEventArgs e)
        {
            if (_hasChanges && !_allowClose)
            {
                e.Cancel = true;
                string choice = await MessageBoxUtil.ShowDialogCustom(this, "Unexported APK changes", "You have staged APK changes. Export a rebuilt APK before closing?", "Export", "Discard", "Cancel");
                if (choice == "Export")
                {
                    bool exported = await ExportRebuiltApkAsync();
                    if (!exported) return;
                }
                else if (choice != "Discard")
                {
                    return;
                }
                _allowClose = true;
                Close();
                return;
            }

            if (_allowClose || !_hasChanges)
            {
                try { if (Directory.Exists(_workingDirectory)) Directory.Delete(_workingDirectory, true); } catch { }
            }
        }
    }

    public sealed class ApkArchiveEntryItem : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        public int OriginalIndex { get; }
        public string OriginalName { get; }
        public bool IsAdded { get; }
        public bool IsDirectory { get; }
        public string Kind { get; }
        public string? ReplacementPath { get; set; }
        private string _name;
        private string _status;
        private long _size;
        private long _compressedSize;
        private bool _isDeleted;

        public ApkArchiveEntryItem(int originalIndex, string name, long size, long compressedSize, string kind, bool isDirectory, bool isAdded)
        {
            OriginalIndex = originalIndex;
            OriginalName = name;
            _name = name;
            _size = size;
            _compressedSize = compressedSize;
            Kind = kind;
            IsDirectory = isDirectory;
            IsAdded = isAdded;
            _status = isAdded ? "Added" : "Original";
        }

        public string Name { get => _name; set { if (_name != value) { _name = value; OnChanged(nameof(Name)); RefreshStatus(); } } }
        public long Size { get => _size; set { if (_size != value) { _size = value; OnChanged(nameof(Size)); OnChanged(nameof(SizeText)); } } }
        public long CompressedSize { get => _compressedSize; set { if (_compressedSize != value) { _compressedSize = value; OnChanged(nameof(CompressedSize)); OnChanged(nameof(PackedSizeText)); } } }
        public bool IsDeleted { get => _isDeleted; set { if (_isDeleted != value) { _isDeleted = value; OnChanged(nameof(IsDeleted)); RefreshStatus(); } } }
        public string Status { get => _status; private set { if (_status != value) { _status = value; OnChanged(nameof(Status)); } } }
        public string SizeText => FormatBytes(Size);
        public string PackedSizeText => CompressedSize < 0 ? "pending" : FormatBytes(CompressedSize);

        public void RefreshStatus()
        {
            if (IsDeleted) Status = "Removed";
            else if (IsAdded) Status = "Added";
            else if (!string.IsNullOrEmpty(ReplacementPath) && Name != OriginalName) Status = "Replaced + renamed";
            else if (!string.IsNullOrEmpty(ReplacementPath)) Status = "Replaced";
            else if (Name != OriginalName) Status = "Renamed";
            else Status = "Original";
        }

        private void OnChanged(string property) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));

        private static string FormatBytes(long bytes)
        {
            string[] units = { "B", "KB", "MB", "GB", "TB" };
            double value = Math.Max(0, bytes);
            int unit = 0;
            while (value >= 1024 && unit < units.Length - 1) { value /= 1024; unit++; }
            return unit == 0 ? $"{(long)value} {units[unit]}" : $"{value:0.##} {units[unit]}";
        }
    }
}