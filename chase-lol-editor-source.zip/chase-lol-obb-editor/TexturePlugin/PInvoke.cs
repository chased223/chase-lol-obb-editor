using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace TexturePlugin
{
    public static class PInvoke
    {
        private const string NativeLibrary = "textoolwrap";

        static PInvoke()
        {
            System.Runtime.InteropServices.NativeLibrary.SetDllImportResolver(typeof(PInvoke).Assembly, ResolveNativeLibrary);
        }

        private static IntPtr ResolveNativeLibrary(string libraryName, Assembly assembly, DllImportSearchPath? searchPath)
        {
            if (!string.Equals(libraryName, NativeLibrary, StringComparison.OrdinalIgnoreCase))
                return IntPtr.Zero;

            string baseDir = AppContext.BaseDirectory;
            string[] candidates =
            {
                Path.Combine(baseDir, "textoolwrap.dll"),
                Path.Combine(baseDir, "TexToolWrap.dll"),
                Path.Combine(baseDir, "runtimes", "win-x64", "native", "textoolwrap.dll"),
                Path.Combine(baseDir, "runtimes", "win-x64", "native", "TexToolWrap.dll")
            };

            foreach (string candidate in candidates)
                if (File.Exists(candidate) && System.Runtime.InteropServices.NativeLibrary.TryLoad(candidate, out IntPtr handle))
                    return handle;

            return IntPtr.Zero;
        }

        [DllImport(NativeLibrary, EntryPoint = "DecodeByCrunchUnity", CallingConvention = CallingConvention.Cdecl)]
        private static extern uint DecodeByCrunchUnityNative(IntPtr data, IntPtr buf, int mode, uint width, uint height, uint byteSize);

        [DllImport(NativeLibrary, EntryPoint = "DecodeByPVRTexLib", CallingConvention = CallingConvention.Cdecl)]
        private static extern uint DecodeByPVRTexLibNative(IntPtr data, IntPtr buf, int mode, uint width, uint height);

        [DllImport(NativeLibrary, EntryPoint = "EncodeByCrunchUnity", CallingConvention = CallingConvention.Cdecl)]
        private static extern uint EncodeByCrunchUnityNative(IntPtr data, ref int checkoutId, int mode, int level, uint width, uint height, uint ver, int mips);

        [DllImport(NativeLibrary, EntryPoint = "PickUpAndFree", CallingConvention = CallingConvention.Cdecl)]
        private static extern bool PickUpAndFreeNative(IntPtr outBuf, uint size, int id);

        [DllImport(NativeLibrary, EntryPoint = "EncodeByPVRTexLib", CallingConvention = CallingConvention.Cdecl)]
        private static extern uint EncodeByPVRTexLibNative(IntPtr data, IntPtr buf, int mode, int level, uint width, uint height);

        [DllImport(NativeLibrary, EntryPoint = "EncodeByISPC", CallingConvention = CallingConvention.Cdecl)]
        private static extern uint EncodeByISPCNative(IntPtr data, IntPtr buf, int mode, int level, uint width, uint height);

        public static uint DecodeByCrunchUnity(IntPtr data, IntPtr buf, int mode, uint width, uint height, uint byteSize)
        {
            try { return DecodeByCrunchUnityNative(data, buf, mode, width, height, byteSize); }
            catch (DllNotFoundException) { return 0; }
            catch (EntryPointNotFoundException) { return 0; }
            catch (BadImageFormatException) { return 0; }
        }

        public static uint DecodeByPVRTexLib(IntPtr data, IntPtr buf, int mode, uint width, uint height)
        {
            try { return DecodeByPVRTexLibNative(data, buf, mode, width, height); }
            catch (DllNotFoundException) { return 0; }
            catch (EntryPointNotFoundException) { return 0; }
            catch (BadImageFormatException) { return 0; }
        }

        public static uint EncodeByCrunchUnity(IntPtr data, ref int checkoutId, int mode, int level, uint width, uint height, uint ver, int mips)
        {
            try { return EncodeByCrunchUnityNative(data, ref checkoutId, mode, level, width, height, ver, mips); }
            catch (DllNotFoundException) { return 0; }
            catch (EntryPointNotFoundException) { return 0; }
            catch (BadImageFormatException) { return 0; }
        }

        public static bool PickUpAndFree(IntPtr outBuf, uint size, int id)
        {
            try { return PickUpAndFreeNative(outBuf, size, id); }
            catch (DllNotFoundException) { return false; }
            catch (EntryPointNotFoundException) { return false; }
            catch (BadImageFormatException) { return false; }
        }

        public static uint EncodeByPVRTexLib(IntPtr data, IntPtr buf, int mode, int level, uint width, uint height)
        {
            try { return EncodeByPVRTexLibNative(data, buf, mode, level, width, height); }
            catch (DllNotFoundException) { return 0; }
            catch (EntryPointNotFoundException) { return 0; }
            catch (BadImageFormatException) { return 0; }
        }

        public static uint EncodeByISPC(IntPtr data, IntPtr buf, int mode, int level, uint width, uint height)
        {
            try { return EncodeByISPCNative(data, buf, mode, level, width, height); }
            catch (DllNotFoundException) { return 0; }
            catch (EntryPointNotFoundException) { return 0; }
            catch (BadImageFormatException) { return 0; }
        }
    }
}
